package com.yash.pms.service;


public interface ProductService {
	public void addProduct() ;
	public void displayProduct();
	public void searchProduct(int productId) ;
	public void updateProduct(int productId);
	public void deleteProduct(int id);

}
