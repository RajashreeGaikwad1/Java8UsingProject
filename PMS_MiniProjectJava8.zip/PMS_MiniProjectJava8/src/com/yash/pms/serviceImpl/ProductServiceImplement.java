package com.yash.pms.serviceImpl;

import java.util.List;
import java.util.stream.Collectors;

import com.yash.pms.model.Product;
import com.yash.pms.service.ProductService;
import com.yash.pms.utility.ProductUtility;

public class ProductServiceImplement extends ProductUtility implements ProductService {

	@Override
	public void addProduct() {
		System.out.println("**********WELCOME************");
		System.out.println("Insert the product id");
		int productId = sc.nextInt();

		System.out.println("Insert the product Name:");
		String productName = sc1.nextLine();

		System.out.println("Insert the product price:");
		int productPrice = sc.nextInt();

		System.out.println("Insert the product Quantity:");
		int productQuantity = sc.nextInt();

		product.add(new Product(productId, productName, productPrice, productQuantity));
		
	}

	@Override
	public void displayProduct() {
		// TODO Auto-generated method stub
		System.out.println("***********PRODUCT DETAILS ************");
		for (Product product : product) {
			System.out.println(product.toString());
		}
		
	}

	@Override
	public void searchProduct(int productId) {
		// TODO Auto-generated method stub
		boolean found = false;
		
		List<Product> li = product.stream().filter(p ->(p.getProductId()==productId)).collect(Collectors.toList());
		if (!li.isEmpty()) {
			li.stream().forEach(p -> System.out.println(p.toString()));
		} 
		else {
			System.out.println("Product not found");
		}
		System.out.println("-----------------");
		
	}

	@Override
	public void  updateProduct(int productId) {
		// TODO Auto-generated method stub
	
		System.out.println("insert the prodct name:");
		String productName = sc1.nextLine();

		System.out.println("insert the prodct price:");
		int productPrice = sc.nextInt();

		System.out.println("insert the prodct Quantity:");
		int productQunty = sc.nextInt();
		List<Product> li=product.stream().map(e -> {

			if (e.getProductId() == productId) {e.setProductName(productName);e.setPrice(productPrice);e.setQuantity(productQunty);
			}

			return e;
		}).collect(Collectors.toList());

		if (li.isEmpty()) {
			System.out.println("Product not found");
		} else {
			System.out.println("Product is updated successfully");
		}
		
	}

	@Override
	public void deleteProduct(int id) {
		// TODO Auto-generated method stub
		/*
		 * System.out.println("Enter the product id "); id = sc.nextInt();
		 */
		List<Product> li = product.stream().filter(p -> p.getProductId() == id).collect(Collectors.toList());
		if (!li.isEmpty()) {
			product.remove(li.get(0));
			System.out.println("Product deleted Successfully");
		} else {
			System.out.println("Product not found");
		}

		System.out.println("******************************");

	
		
	}

}
