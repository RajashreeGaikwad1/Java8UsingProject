package com.yash.pms.test;

import com.yash.pms.utility.ProductUtility;

public class ProductTest extends ProductUtility {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String userinput;
		int exit = 0;
		
		
		while (exit == 0){ 
		
			System.out.println("1.Add");
			System.out.println("2.Display");
			System.out.println("3.Search");
			System.out.println("4.Update");
			System.out.println("5.Delete");
			System.out.println("6.Terminate");
			System.out.println("Enter your choice");
		
		 userinput = sc.next();
			switch (userinput) {

			case "Add":
				productImplement.addProduct();
				break;

			case "Display":

				productImplement.displayProduct();

				break;

			case "Search":
				System.out.println("Enter Product ID to Search");
				int productId = sc.nextInt();
				productImplement.searchProduct(productId);
				break;

			case "Update":
				System.out.println("please enter the product id for update");
				int id1 = sc.nextInt();
				productImplement.updateProduct(id1);
				break;

			case "Delete":
				System.out.println("please enter the product id which you want delete");
				int id= sc.nextInt();
	
				productImplement.deleteProduct(id);
				break;
				
			case "Terminate":
				System.out.println("Terminated!!");
				System.exit(0);
				break;

			default:
				break;

			}

			
		}
	}

}
