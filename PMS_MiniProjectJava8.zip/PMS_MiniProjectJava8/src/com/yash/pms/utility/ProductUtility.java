package com.yash.pms.utility;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.yash.pms.model.Product;
import com.yash.pms.serviceImpl.ProductServiceImplement;


public class ProductUtility {
	protected List<Product> product = new ArrayList<Product>();
	protected  static Scanner sc = new Scanner(System.in);
	protected Scanner sc1 = new Scanner(System.in);
	
	protected static ProductServiceImplement productImplement=new ProductServiceImplement();
}
